# 印尼电力招标与政策监测（原型）

## 部署（约15分钟）
1. 在 GitHub 新建仓库，把本文件夹全部内容上传（注意保留 .github 隐藏文件夹）。
2. 仓库 Settings → Secrets and variables → Actions → New secret：名称 ANTHROPIC_API_KEY，值为你的 API Key。
3. Actions 页面选 daily-collect → Run workflow，手动跑一次，确认 docs/data.json 有内容。
4. 发布网页（二选一）：
   - GitHub Pages：Settings → Pages → Branch 选 main，文件夹选 /docs
   - Cloudflare Pages / Vercel：连接仓库，输出目录填 docs
5. 之后每天北京时间 08:00 自动更新。

## 本地试跑
pip install -r requirements.txt
export ANTHROPIC_API_KEY=你的key
python collect.py
cd docs && python -m http.server 8000   # 浏览器打开 localhost:8000

## 自定义
- 检索词：改 collect.py 里的 QUERIES
- 官方来源：核实 RSS 地址后加入 EXTRA_FEEDS
- 模型：环境变量 MODEL
